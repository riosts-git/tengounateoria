# Tengo una Teoría

Blog estático con Astro. Sin base de datos: cada texto es un archivo Markdown y cada uno tiene su propia URL.

## Publicar en GitHub (una sola vez)
1. Sube todo el contenido de esta carpeta al repositorio `riosts-git/tengounateoria` (rama `main`).
2. En GitHub: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Cada `push` a `main` construye y publica la web en `https://riosts-git.github.io/tengounateoria/`.

## Añadir contenido
Crea un `.md` en la carpeta que corresponda:

| Tipo | Carpeta | URL |
|---|---|---|
| Ensayo | `src/content/ensayos/` | `/ensayos/nombre-del-archivo/` |
| Libro | `src/content/libros/` | `/libros/nombre-del-archivo/` |
| Foto | `src/content/fotos/` | `/fotos/nombre-del-archivo/` |

Cabecera de cada archivo:

```yaml
---
title: Título
date: 2026-06-01
description: Una frase para Google y para compartir en redes.
categoria: intuición   # intuición | emociones arquetípicas | el árbol de arquetipos | consciencia
tags: [miedo, cuerpo]
draft: false           # true = no se publica
---
```
- **Ensayo dentro de un libro:** añade `libro: nombre-del-archivo-del-libro` y `orden: 1`. El índice del libro se genera solo.
- **Foto real:** guarda la imagen en `public/fotos/` y añade `image: fotos/nombre.jpg` (y `alt:` con su descripción).
- Cambiar las categorías: edita `CATS` en `src/config.ts`.

## Antes de publicar de verdad
- En `src/config.ts`, cambia `author: 'TU NOMBRE'`.
- Borra los archivos de ejemplo de `src/content/`.
- Si usas dominio propio: en `astro.config.mjs` cambia `site` y elimina la línea `base`.

## En local
```
npm install
npm run dev      # http://localhost:4321/tengounateoria/
npm run build
```

## Pendiente (fase 2)
Comentarios y reacciones, formulario de suscripción, panel de administración, atlas de emociones/arquetipos.
